// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <comutil.h>
#include <sqloledb.h>
#include <tchar.h>

#ifdef _UNICODE
#define FILEMODE TEXT("r,ccs=UNICODE")
#define MEOF WEOF
#else
#define FILEMODE TEXT("r")
#define MEOF EOF
#endif

#include <iostream>

class SQL_Script{
public:
    SQL_Script(void);
    ~SQL_Script(void);
    bool Init(TCHAR *scriptFile);
    int Execute(void);
    int ExecuteSSMSScript(void);
private:
    TCHAR *Command;
    FILE *file;
    HANDLE heap;
    SIZE_T fileLen;
};

SQL_Script::~SQL_Script()
{
    if(Command!=NULL)
        HeapFree(heap,0,Command);
    if(file!=NULL)
        fclose(file);
} // ~SQL_Script

SQL_Script::SQL_Script() : fileLen(0), Command(NULL), file(NULL)
{
    heap=GetProcessHeap();
} // SQL_Script

bool SQL_Script::Init(TCHAR *scriptFile)
{
    errno_t err;
    err=_tfopen_s(&file,scriptFile,FILEMODE);
    if(err)
        return(false);
    long startFile=ftell(file); // save starting of file
    fseek(file,0L,SEEK_END);
    fileLen=ftell(file);
    fseek(file,startFile,SEEK_SET); // reposition at start of file
    Command=(TCHAR *)HeapAlloc(heap,0,fileLen+1);
    if(Command==NULL)
        return(false);
    return(true);
} // Init

int SQL_Script::Execute(void)
{

    int hr;
    long pos=0L;
    while (!feof(file))
    {
        TCHAR c=_fgettc(file);
        if(c!=MEOF)
        {
            Command[pos]=c;
            ++pos;
        }
    } ;
    Command[pos]=_T('\0');
    return(hr);
} // Execute

int  SQL_Script::ExecuteSSMSScript(void)
{
    int hr = 0;
    long pos = 0L;
    TCHAR buf[32];
    int currBufLen = 0;
    const TCHAR pattern[] = {TEXT('G'), TEXT('O'), TEXT('\n')};
    while(!feof(file)){
        TCHAR c = _fgettc(file);
        if(c != MEOF){
            //if(c == 0xD){
            //    buf[currBufLen++] = c;
            //}else 

            if(c == 0xA){
                buf[currBufLen++] = c;
            }else if(c == TEXT('G')){
                buf[currBufLen++] = c;
            }else if(c == TEXT('O')){
                buf[currBufLen++] = c;
            }else if (currBufLen > 0){
                buf[currBufLen++] = c;
            }
            if(currBufLen > 0){
                int cmpRes = _tcsncmp(buf, pattern, currBufLen);
                if(cmpRes == 0){
                    if(currBufLen > 2){
                        currBufLen = 0;

                        Command[pos] = _T('\0');
                        std::cout << Command << std::endl;
                        pos = 0;
                    }
                    continue;
                }else{
                    _tcsncpy(&Command[pos], buf, currBufLen);
                    pos += currBufLen;
                    currBufLen = 0;
                    continue;
                }
            }
            Command[pos++] = c;
        }
    }
    Command[pos]=_T('\0');
    std::cout << Command << std::endl;
    return(hr);
} // Execute

int _tmain(int argc, _TCHAR* argv[])
{
    SQL_Script test;
    test.Init("c:\\talnakh3_database.sql");
    test.ExecuteSSMSScript();
    std::cin.get();
	return 0;
}

