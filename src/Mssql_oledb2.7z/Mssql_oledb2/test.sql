SELECT @@version
