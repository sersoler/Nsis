/* MSSQL OLEDB plugin for NSIS
* Copyright (C) 2007 Stefano Giusto <sgiusto@mmpoint.it>
*
* This software is provided 'as-is', without any express or implied 
* warranty. In no event will the authors be held liable for any damages 
* arising from the use of this software. 
*
* Permission is granted to anyone to use this software for any purpose, 
* including commercial applications, and to alter it and redistribute it 
* freely, subject to the following restrictions:
*
*   1. The origin of this software must not be misrepresented; you must not 
*      claim that you wrote the original software. If you use this software 
*      in a product, an acknowledgment in the product documentation would be
*      appreciated but is not required.
*
*   2. Altered source versions must be plainly marked as such, and must not 
*      be misrepresented as being the original software.
*
*   3. This notice may not be removed or altered from any source 
*      distribution.
* ------------------------------------------------------------------------------
* Version History
* 1.0.0.0 03/12/2007 first release
* 1.1.0.0 03/20/2007 fixed a bug in DllMain in Windows 2000
* 1.2.0.0 03/29/2007 Added SQL_ExecuteScript function
* 1.3.0.0 05/24/2007 Fixed a bug in Data Column Binding causing data truncation in rowsets
* 1.4.0.0 09/11/2007 added support for Unicode SQL scripts in SQL_ExecuteScript function
* 2.0.0.0 11/04/2009 added support for new plugin api
*                    added unicode version
*                    script length is limited by memory
* 2.0.1.0 01/08/2009 Fixed an allocation bug. Global variables were not set to null after deletion in SQL_Logout function
*/
#define NO_TEST
#if defined(UNICODE) | defined(_UNICODE)
#define OLEDB_MAX_STRING_LENGTH 8192
#else
#define OLEDB_MAX_STRING_LENGTH 1024
#endif

#include <windows.h>
#include <stdio.h>
#include <comutil.h>
#include <sqloledb.h>
//#include "..\ExDLL\exdll.h"
#include "unicode/pluginapi.h"
#include <tchar.h>
#include "./include/MMSQLOLEDB.h"
#include "./include/MMSQLQuery.h"
#include "./include/MMSQLError.h"
#include "./MSSQL_OLEDB.h"
#if !defined(NO_TEST)
    #include "debugtrace.h"
#endif

static UINT_PTR PluginCallback(enum NSPIM msg)
{
    return 0;
}
#if defined(NO_TEST)
BOOL WINAPI DllMain(
                    HINSTANCE hinstDLL,  // handle to DLL module
                    DWORD fdwReason,     // reason for calling function
                    LPVOID lpReserved )  // reserved
{
    // Perform actions based on the reason for calling.
    switch( fdwReason ) 
    { 
    case DLL_PROCESS_ATTACH:
        g_hInstance=(HINSTANCE) hinstDLL;
        db=NULL;
        q=NULL;
        break;

    case DLL_THREAD_ATTACH:
        break;

    case DLL_THREAD_DETACH:
        break;

    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;  // Successful DLL_PROCESS_ATTACH.
}
#endif


void SQL_Logout(HWND hwndParent, int string_size, 
                TCHAR *variables, stack_t **stacktop,
                extra_parameters *extra)
{
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("0"));
#endif
    g_hwndParent=hwndParent;

#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("1"));
    EXDLL_INIT();
    nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("2"));
#else
    EXDLL_INIT();
#endif
        
    if(q)
    {
#if !defined(NO_TEST)
        nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("3"));
#endif
        delete q;
        q=NULL;
    }
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("4"));
#endif
    if(db)
    {
#if !defined(NO_TEST)
        nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("5"));
#endif
        delete db;
        db=NULL;
    }
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Logout: %s"), VTEXT("6"));
#endif
}

void SQL_Logon(HWND hwndParent, int string_size, 
               TCHAR *variables, stack_t **stacktop,
               extra_parameters *extra)
{
#ifdef NO_TEST
    g_hwndParent=hwndParent;
    extra->RegisterPluginCallback(g_hInstance, PluginCallback);

    EXDLL_INIT();
#endif

    // note if you want parameters from the stack, pop them off in order.
    // i.e. if you are called via exdll::myFunction file.dat poop.dat
    // calling popstring() the first time would give you file.dat,
    // and the second time would give you poop.dat. 
    // you should empty the stack of your parameters, and ONLY your
    // parameters.

    {
        VARIANT v;
        _bstr_t bstr;
        if(q)
        {
            delete q;
            q=NULL;
        }
        if(db)
        {
            delete db;
            db=NULL;
        }
        db=new MMSQLOLEDB();
        db->Initialize();
        if(!db->IsInitialized())
        {
#ifdef NO_TEST
            pushstring(TEXT("Error initializing OLEDB Environment (!IsInitialized)"));
            pushstring(TEXT("1"));
#endif
            return;
        }
        if(!db->IsOk())
        {
#ifdef NO_TEST
            pushstring(TEXT("Error initializing OLEDB Environment (!IsOk)"));
            pushstring(TEXT("1"));
#endif
            return;
        }
        V_VT(&v)=VT_I4;
        V_I4(&v)=10;
        hr=db->AddProperty(&v,DBPROP_INIT_TIMEOUT);
#ifdef NO_TEST
        TCHAR ServerName[64] = {0};
        if(popstring(ServerName))
        {
            pushstring(TEXT("Invalid number of arguments"));
            pushstring(TEXT("1"));
            return;
        }
#else
        //TCHAR ServerName[64] = TEXT("(local)");
        TCHAR ServerName[64] = TEXT("VMSTATION\SQLEXPRESS");
#endif
        bstr=(TCHAR *)ServerName;
        V_VT(&v)=VT_BSTR;
        V_BSTR(&v)=bstr;
        hr=db->AddProperty(&v,DBPROP_INIT_DATASOURCE);

#ifdef NO_TEST
        TCHAR SQLUser[64] = {0};
        if(popstring(SQLUser))
        {
            pushstring(TEXT("Invalid number of arguments"));
            pushstring(TEXT("1"));
            return;
        }
#else
        TCHAR SQLUser[64] = TEXT("sa");
#endif
        bstr=SQLUser;
        V_VT(&v)=VT_BSTR;
        V_BSTR(&v)=bstr;
        hr=db->AddProperty(&v,DBPROP_AUTH_USERID);

#ifdef NO_TEST
        TCHAR SQLPassword[64] = {0};
        if(popstring(SQLPassword))
        {
            pushstring(TEXT("Invalid number of arguments"));
            pushstring(TEXT("1"));
            return;
        }
#else
        TCHAR SQLPassword[64] = TEXT("s");
#endif
        bstr=SQLPassword;
        V_VT(&v)=VT_BSTR;
        V_BSTR(&v)=bstr;
        hr=db->AddProperty(&v,DBPROP_AUTH_PASSWORD);
        V_BSTR(&v)=NULL;
        // if username is blank use integrated authentication
        if(_tcslen(SQLUser)==0)
        {
            hr=db->AddProperty(&v,DBPROP_AUTH_INTEGRATED);
        }

        hr=db->SetInitProps();
        if(FAILED(hr))
        {
#ifdef NO_TEST
            pushstring(TEXT("Error initializing OLEDB Connection (SetInitProps)"));
            pushstring(TEXT("1"));
#endif
            return;
        }

        hr=db->GetDBI()->Initialize();
        if(FAILED(hr))
        {
#ifdef NO_TEST
            pushstring(TEXT("Error initializing OLEDB Connection (Initialize)"));
            pushstring(TEXT("1"));
#endif
            return;
        }
#ifdef NO_TEST
        pushstring(TEXT("Logon successfull"));
        pushstring(TEXT("0"));
#endif
    }
}

void SQL_Execute(HWND hwndParent, int string_size, 
                 TCHAR *variables, stack_t **stacktop,
                 extra_parameters *extra)
{
    g_hwndParent=hwndParent;
#ifdef NO_TEST
    EXDLL_INIT();
#endif
    {
        TCHAR command[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
#ifdef NO_TEST
        if(popstring(command))
        {
            pushstring(TEXT("Invalid number of arguments"));
            pushstring(TEXT("1"));
            return;
        }
#endif
        if(q){
            delete q;
            q = 0;
        }
        q = new MMSQLQuery(db);
        hr=q->Statement()->SetCommandText(command);
        hr=q->Execute();
        if(FAILED(hr))
        {
#ifdef NO_TEST
            pushstring(TEXT("Query Failed"));
            pushstring(TEXT("1"));
#endif
        }
        else
        {
#ifdef NO_TEST
            pushstring(TEXT("Query Successfull"));
            pushstring(TEXT("0"));
#endif
        }

    }

}

void SQL_GetRow(HWND hwndParent, int string_size, 
                TCHAR *variables, stack_t **stacktop,
                extra_parameters *extra)
{
    g_hwndParent=hwndParent;

#ifdef NO_TEST
    EXDLL_INIT();
#endif
    if(!q)
    {
#ifdef NO_TEST
        pushstring(TEXT("No query"));
        pushstring(TEXT("1"));
#endif
        return;
    }
    TCHAR row[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
    TCHAR col[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
    ULONG ncols=0L;
    ULONG i;
    if(!q->RS()->GetRowset())
    {
#ifdef NO_TEST
        pushstring(TEXT("Error getting rowset"));
        pushstring(TEXT("1"));
#endif
        return;
    }
    if(FAILED(q->RS()->Init()))
    {
#ifdef NO_TEST
        pushstring(TEXT("Error initializing rowset"));
        pushstring(TEXT("1"));
#endif
        return;
    }
    ncols=q->RS()->GetNCols();
    row[0]=_T('\0');
    if(!q->RS()->FetchRecord())
    {
#ifdef NO_TEST
        pushstring(TEXT("No more data"));
        pushstring(TEXT("2"));
#endif
        return;
    }

    int stringSize = 0;
    int maxlen = OLEDB_MAX_STRING_LENGTH - 1;
    for(i=0; i<ncols; i++){
        int colSize = q->RS()->GetCol(i, col, OLEDB_MAX_STRING_LENGTH - 1);
        maxlen -= stringSize;
        if(maxlen <= 0){
            break;
        }
        if(i>0){
            _tcsncpy(row + stringSize, TEXT("|"), maxlen);
            stringSize += 1;
            maxlen -= stringSize;
            if(maxlen <= 0){
                break;
            }
            _tcsncpy(row + stringSize, col, maxlen);
        }else{
            _tcsncpy(row + stringSize, col, maxlen);
        }
        stringSize += colSize;

        //if(i>0){
        //    _stprintf_s(row,OLEDB_MAX_STRING_LENGTH - 1,TEXT("%s|"),row);
        //}
        //_stprintf_s(row,OLEDB_MAX_STRING_LENGTH - 1,TEXT("%s%s"),row,col);

        ////// Format and print various data: 
        ////j  = sprintf_s( buffer, 200,     "   String:    %s\n", s );
        ////j += sprintf_s( buffer + j, 200 - j, "   Character: %c\n", c );
        ////j += sprintf_s( buffer + j, 200 - j, "   Integer:   %d\n", i );
        ////j += sprintf_s( buffer + j, 200 - j, "   Real:      %f\n", fp );
    }
#ifdef NO_TEST
    pushstring(row);
    pushstring(TEXT("0"));
#endif
}

void SQL_GetError(HWND hwndParent, int string_size, 
                  TCHAR *variables, stack_t **stacktop,
                  extra_parameters *extra)
{
    g_hwndParent=hwndParent;

    EXDLL_INIT();
    TCHAR Errors[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
    Errors[0]=_T('\0');
    MMSQLError err;
    err.ReportErrors(hr,Errors,OLEDB_MAX_STRING_LENGTH - 1);
#ifdef NO_TEST
    pushstring(Errors);
    pushstring(TEXT("0"));
#endif
}


void SQL_ExecuteScript(HWND hwndParent, int string_size, 
                       TCHAR *variables, stack_t **stacktop,
                       extra_parameters *extra)
{
    g_hwndParent=hwndParent;
#ifdef NO_TEST
    EXDLL_INIT();
#endif
    
#if !defined(NO_TEST)
    TCHAR fname[OLEDB_MAX_STRING_LENGTH] = VTEXT("d:\\Users\\Soler\\soft\\Programming\\NSIS\\Plugins\\Mssql_oledb2\\test.sql");
    nsV::_VTRACE(VTEXT("SQL_ExecuteScript: %s"), VTEXT("+SQL_Script s"));
#else
    TCHAR fname[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
#endif
    SQL_Script s;
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_ExecuteScript: %s"), VTEXT("-SQL_Script s"));
#endif
#ifdef NO_TEST
    if(popstring(fname))
    {
        pushstring(TEXT("Invalid number of arguments"));
        pushstring(TEXT("1"));
        return;
    }
#endif
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_ExecuteScript: %s"), VTEXT("if(!s.Init(fname))"));
#endif
    if(!s.Init(fname))
    {
#ifdef NO_TEST
        pushstring(TEXT("Error initializing script"));
        pushstring(TEXT("1"));
#endif
        return;
    }
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_ExecuteScript: %s"), VTEXT("+if(FAILED(s.Execute()))"));
#endif
    if(FAILED(s.Execute()))
    {
#ifdef NO_TEST
        pushstring(TEXT("Error executing script"));
        pushstring(TEXT("1"));
#endif
        return;
    }
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_ExecuteScript: %s"), VTEXT("-if(FAILED(s.Execute()))"));
#endif
#ifdef NO_TEST
    pushstring(TEXT("Script executed successfully"));
    pushstring(TEXT("0"));
#endif
    return;
} // SQL_ExecuteScript

void SQL_ExecuteSSMSScript(HWND hwndParent, int string_size, 
                           TCHAR *variables, stack_t **stacktop,
                           extra_parameters *extra)
{
    g_hwndParent=hwndParent;

    EXDLL_INIT();
    TCHAR fname[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
    SQL_Script s;
    if(popstring(fname))
    {
        pushstring(TEXT("Invalid number of arguments"));
        pushstring(TEXT("1"));
        return;
    }
    if(!s.Init(fname))
    {
        pushstring(TEXT("Error initializing script"));
        pushstring(TEXT("1"));
        return;
    }
    if(FAILED(s.ExecuteSSMSScript()))
    {
        pushstring(TEXT("Error executing script"));
        pushstring(TEXT("1"));
        return;
    }
    pushstring(TEXT("Script executed successfully"));
    pushstring(TEXT("0"));
    return;
} // SQL_ExecuteSSMSScript

void SQL_ExecuteTalnakhV3Importer(HWND hwndParent, int string_size, 
                           TCHAR *variables, stack_t **stacktop,
                           extra_parameters *extra)
{
    g_hwndParent=hwndParent;

    EXDLL_INIT();
    TCHAR fname[OLEDB_MAX_STRING_LENGTH] = {_T('\0')};
    if(popstring(fname))
    {
        pushstring(TEXT("Invalid number of arguments"));
        pushstring(TEXT("1"));
        return;
    }

    //if(!s.Init(fname))
    //{
    //    pushstring(TEXT("Error initializing script"));
    //    pushstring(TEXT("1"));
    //    return;
    //}
    //if(FAILED(s.ExecuteSSMSScript()))
    //{
    //    pushstring(TEXT("Error executing script"));
    //    pushstring(TEXT("1"));
    //    return;
    //}
    pushstring(TEXT("Script executed successfully"));
    pushstring(TEXT("0"));
    return;
} // SQL_ExecuteSSMSScript

SQL_Script::~SQL_Script()
{
    if(Command!=NULL)
        HeapFree(heap,0,Command);
    if(file!=NULL)
        fclose(file);
} // ~SQL_Script

SQL_Script::SQL_Script() : fileLen(0), Command(NULL), file(NULL)
{
    heap=GetProcessHeap();
} // SQL_Script

bool SQL_Script::Init(TCHAR *scriptFile)
{
    errno_t err;
    err=_tfopen_s(&file,scriptFile,FILEMODE);
    if(err)
        return(false);
    long startFile=ftell(file); // save starting of file
    fseek(file,0L,SEEK_END);
    fileLen=ftell(file);
    fseek(file,startFile,SEEK_SET); // reposition at start of file
    Command=(TCHAR *)HeapAlloc(heap,0,(fileLen+1) * sizeof(TCHAR));
    if(Command==NULL)
        return(false);
    return(true);
} // Init

HRESULT SQL_Script::Execute(void)
{

    HRESULT hr;
    long pos=0L;
    while(!feof(file)){
        TCHAR c=_fgettc(file);
        if(c!=MEOF) {
            Command[pos]=c;
            ++pos;
        }
    }
    Command[pos]=_T('\0');
    if(q){
        delete q;
        q = 0;
    }
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Script::Execute: Command = %s"), Command);
#endif
    q=new MMSQLQuery(db);
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Script::Execute: q=new MMSQLQuery(db)"));
#endif
    hr=q->Statement()->SetCommandText(Command);
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Script::Execute: hr=q->Statement()->SetCommandText(Command)"));
#endif
    if(FAILED(hr))
    {
        return(hr);
    }
    hr=q->Execute();
#if !defined(NO_TEST)
    nsV::_VTRACE(VTEXT("SQL_Script::Execute: hr=q->Execute()"));
#endif
    return(hr);
} // Execute

HRESULT SQL_Script::ExecuteSSMSScript(void)
{
    HRESULT hr;
    long pos = 0L;
    TCHAR buf[32] = {0};
    int currBufLen = 0;
    const TCHAR pattern[] = {TEXT('G'), TEXT('O'), TEXT('\n')};
    while(!feof(file)){
        TCHAR c = _fgettc(file);
        if(c != MEOF){
            if(c == 0xA){
                buf[currBufLen++] = c;
            }else if(c == TEXT('G')){
                buf[currBufLen++] = c;
            }else if(c == TEXT('O')){
                buf[currBufLen++] = c;
            }else if (currBufLen > 0){
                buf[currBufLen++] = c;
            }
            if(currBufLen > 0){
                int cmpRes = _tcsncmp(buf, pattern, currBufLen);
                if(cmpRes == 0){
                    if(currBufLen > 2){
                        Command[pos] = _T('\0');
                        if(q){
                            delete q;
                            q = 0;
                        }
                        q = new MMSQLQuery(db);
                        hr = q->Statement()->SetCommandText(Command);
                        if(FAILED(hr)){
                            return(hr);
                        }
                        hr = q->Execute();
                        currBufLen = 0;
                        pos = 0;
                    }
                    continue;
                }else{
                    _tcsncpy(&Command[pos], buf, currBufLen);
                    pos += currBufLen;
                    currBufLen = 0;
                    continue;
                }
            }
            Command[pos++] = c;
        }
    }
    Command[pos]=_T('\0');
    if(q){
        delete q;
        q = 0;
    }
    if(pos > 0){
        q=new MMSQLQuery(db);
        hr=q->Statement()->SetCommandText(Command);
        if(FAILED(hr))
        {
            return(hr);
        }
        hr=q->Execute();
    }
    return(hr);
} // Execute

#if !defined(NO_TEST)
int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR    lpCmdLine,
                       int       nCmdShow)
{
    SQL_Logon(0, OLEDB_MAX_STRING_LENGTH, 0, 0, 0);
    SQL_ExecuteScript(0, OLEDB_MAX_STRING_LENGTH, 0, 0, 0);
    SQL_Logout(0, OLEDB_MAX_STRING_LENGTH, 0, 0, 0);
}
#endif
