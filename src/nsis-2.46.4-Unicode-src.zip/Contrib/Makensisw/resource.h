//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDS_LOADSCRIPT                  1
#define IDS_SAVE                        2
#define IDS_EXIT                        3
#define IDLOAD                          3
#define IDS_COPY                        4
#define IDSAVE                          4
#define IDS_FIND                        5
#define IDCLEAR                         5
#define IDS_RECOMPILE                   6
#define IDS_SETTINGS                    7
#define IDS_COMPRESSOR                  8
#define IDS_TEST                        9
#define IDS_EDITSCRIPT                  10
#define IDS_BROWSESCR                   11
#define IDS_CLEARLOG                    12
#define IDS_NSISHOME                    13
#define IDS_FORUM                       15
#define IDS_NSISUPDATE                  16
#define IDS_DOCS                        17
#define IDS_SCRIPT                      18
#define IDS_ZLIB                        19
#define IDS_ZLIB_SOLID                  20
#define IDS_BZIP2                       21
#define IDS_BZIP2_SOLID                 22
#define IDS_RECOMPILE_TEST              23
#define IDS_BEST                        24
#define IDS_LZMA                        25
#define IDS_LZMA_SOLID                  26
#define DLG_MAIN                        101
#define IDI_ICON                        102
#define DLG_ABOUT                       103
#define IDM_MENU                        104
#define IDK_ACCEL                       105
#define IDI_SHELL                       112
#define IDB_LOGO                        115
#define DLG_SETTINGS                    116
#define IDB_BITMAP1                     120
#define IDB_TOOLBAR                     122
#define DLG_COMPRESSOR                  124
#define DLG_SYMBOLSET                   125
#define IDB_TOOLBAR24                   129
#define IDB_TOOLBAR24D                  130
#define IDB_BITMAP2                     131
#define IDB_TOOLBAR24H                  132
#define IDC_LOGWIN                      402
#define IDC_VERSION                     405
#define IDM_ABOUT                       501
#define IDM_EXIT                        502
#define IDM_SAVE                        503
#define IDM_COPY                        504
#define IDM_COPYSELECTED                505
#define IDM_RECOMPILE                   506
#define IDM_NSISHOME                    507
#define IDC_TEST                        1000
#define IDC_ABOUTVERSION                1001
#define IDC_ABOUTCOPY                   1003
#define IDC_ABOUTPORTIONS               1005
#define IDC_CONTRIB                     1009
#define IDC_NSISVER                     1010
#define IDC_OTHERCONTRIB                1016
#define IDC_SYMBOL                      1017
#define IDC_VALUE                       1018
#define IDRIGHT                         1019
#define IDLEFT                          1020
#define IDC_SYMBOLS                     1021
#define IDC_RECOMPILE_TEST              1022
#define IDC_COMPRESSOR                  1025
#define IDC_NAMES                       1027
#define IDDEL                           1028
#define IDM_COMPRESSOR                  40001
#define IDM_TEST                        40002
#define IDM_EDITSCRIPT                  40003
#define IDM_DOCS                        40004
#define IDM_LOADSCRIPT                  40005
#define IDM_FIND                        40006
#define IDM_SELECTALL                   40007
#define IDM_CLEARLOG                    40009
#define IDM_BROWSESCR                   40013
#define IDM_FORUM                       40016
#define IDM_NSISUPDATE                  40018
#define IDM_COMPRESSOR_SCRIPT           40020
#define IDM_ZLIB                        40021
#define IDM_ZLIB_SOLID                  40022
#define IDM_BZIP2                       40023
#define IDM_BZIP2_SOLID                 40024
#define IDM_LZMA                        40025
#define IDM_LZMA_SOLID                  40026
#define IDM_MRU_FILE                    40027
#define IDM_CLEAR_MRU_LIST              40032
#define IDM_RECOMPILE_TEST              40033
#define IDM_BEST                        40034
#define IDM_SETTINGS                    40035
#define IDM_CANCEL                      40036
#define IDM_FILE                        40037
#define IDM_EDIT                        40038
#define IDM_SCRIPT                      40039
#define IDM_COMPRESSOR_SUBMENU          40040
#define IDM_TOOLS                       40041
#define IDM_HELP                        40042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         40043
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
