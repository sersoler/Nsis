#ifndef __NS_DIALOGS__INPUT_H__
#define __NS_DIALOGS__INPUT_H__

#include "defs.h"

int NSDFUNC PopPlacement(int *x, int *y, int *width, int *height);

#endif//__NS_DIALOGS__INPUT_H__
