// ThreadTimer.cpp : Defines the entry point for the DLL application.

#include <windows.h>
#include <process.h>
#include <string.h>
#include "exdll.h"
#include "ThreadTimer.h"
#include <tchar.h>

BOOL APIENTRY DllMain(HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

DELAY_API void Start(HWND hwndParent, int string_size,
                             TCHAR *variables, stack_t **stacktop, extra_parameters *extra)
{
	TCHAR* tmp;
	int iTemp = 0; 
	unsigned uThreadID;
	HANDLE hThread;
	wchar_t *wText;
	int len = 0;

	// Initialize DLL
	g_stringsize = string_size; 
	g_stacktop = stacktop;   

#ifdef UNICODE
	len = strlen(variables)+1;
	wText = (wchar_t*)malloc(len);
	if ( wText == 0 )
	{
		extra->exec_flags->exec_error = TRUE;
		return; // Error getting string
	}
	//memset(wText,0,leng);
	//mbtowc(wText, variables, len );
	g_variables = variables; 
#else
	g_variables = variables; 
#endif

	// Get parameters from NSIS
	tmp = (TCHAR*) malloc (MAX_PATH);
	// Interval for Timer
	if(popstring(tmp)) 
	{
		extra->exec_flags->exec_error = TRUE;
		pushstring("1");
		return;
	}
	iTemp = _AWtoI(tmp);
	if(iTemp <= 0) 
	{
		extra->exec_flags->exec_error = TRUE;
		pushstring("1");
		return;
	}
	else
		g_ThreadParam.iInterval = iTemp;

	// Number of ticks, -1 is infinite!
	if(popstring(tmp)) 
	{
		extra->exec_flags->exec_error = TRUE;
		pushstring("2");
		return;
	}
	iTemp = _AWtoI(tmp);
	if(iTemp <= 0) 
	{
		// Infinite loop
		g_ThreadParam.iDelay = -1;
	}
	else
		g_ThreadParam.iDelay = iTemp;

	// Pointer to NSIS function
	if(popstring(tmp)) 
	{
		extra->exec_flags->exec_error = TRUE;
		return;
	}
	iTemp = _AWtoI(tmp);
	if(iTemp <= 0) 
	{
		extra->exec_flags->exec_error = TRUE;
		pushstring("3");
		return;
	}
	else
		g_ThreadParam.iFunction = iTemp;

	// Pointer to extra_parameters
	g_ThreadParam.extra = extra;
	g_bStopImmediately = FALSE;

    free(tmp);
	//hThread = (HANDLE)_beginthreadex(NULL, 0, ThreadProc, &g_ThreadParam, 0, &uThreadID);
	hThread = (HANDLE)CreateThread(NULL, 0, ThreadProc, &g_ThreadParam, 0, &uThreadID);
	CloseHandle(hThread);
}

DELAY_API void Stop(HWND hwndParent, int string_size,
                             TCHAR *variables, stack_t **stacktop, extra_parameters *extra)
{
	g_bStopImmediately = TRUE;
	//_endthreadex(0);
}

DWORD WINAPI ThreadProc(void * param)
{
	THREADPARAM * pThreadParam = (THREADPARAM *)param;
	int i = 0;

	if( pThreadParam->iDelay == -1)
	{
		// Infinite loop
		while(!g_bStopImmediately)
		{
			Sleep(pThreadParam->iInterval);
			pThreadParam->extra->ExecuteCodeSegment(pThreadParam->iFunction-1, 0); // Do not forget to iFunction-1 !!!			
		}
		// Kill this process to stop this loop!!!
	}
	else
	{
		// Do pThreadParam->iDelay steps
		for(i = 0; i < pThreadParam->iDelay; i++)
		{
			if(g_bStopImmediately)
			{
				// Stop process
				break;
			}
			Sleep(pThreadParam->iInterval);
			if(g_bStopImmediately)
			{
				// Stop process
				break;
			}
			pThreadParam->extra->ExecuteCodeSegment(pThreadParam->iFunction-1, 0); // Do not forget to iFunction-1 !!!		
		}
	}
	return 0;
}

