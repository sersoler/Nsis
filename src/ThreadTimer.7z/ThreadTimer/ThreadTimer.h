#ifndef _THREAD_TIMER_H_ 
#define _THREAD_TIMER_H_

#include "exdll.h"

#ifdef __cplusplus
  extern "C"
#endif

typedef struct _THREADPARAM
{	
	HWND hWnd;
	int iInterval;
	int iDelay;
	int iFunction;
	extra_parameters *extra;
} THREADPARAM;

static THREADPARAM g_ThreadParam;
static BOOL g_bStopImmediately;

unsigned __stdcall ThreadProc(void * param);

_declspec(dllexport) void Start(HWND hwndParent, int string_size,
					 char *variables, stack_t **stacktop, extra_parameters *extra);

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the DELAY_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// DELAY_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.

#ifdef DELAY_EXPORTS
#define DELAY_API __declspec(dllexport)
#else
#define DELAY_API __declspec(dllimport)
#endif

#ifdef UNICODE
#define _AWtoI(x) wtoi(x)
#else
#define _AWtoI(x) atoi(x)
#endif

#endif


